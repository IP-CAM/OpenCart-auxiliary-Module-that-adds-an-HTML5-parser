<?php

/*
@name     Html5
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  2.8.1
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/lib-html5
@licence  https://github.com/ocmod-space/lib-html5/main/LICENSE.txt
*/

$_['heading_title'] = '#ocmod.space: html5';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit <b>Html5</b>';
$_['text_made'] = 'Made with <i class="fa fa-heart-o" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> in Ukraine';
$_['text_about'] = 'The module adds <a target="_blank" href="https://github.com/masterminds/html5-php">Masterminds</a> HTML5 parser to the OpenCart vendor library.';
