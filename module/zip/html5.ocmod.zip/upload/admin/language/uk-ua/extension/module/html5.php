<?php

/*
@name     Html5
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  2.8.1
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/lib-html5
@licence  https://github.com/ocmod-space/lib-html5/main/LICENSE.txt
*/


$_['heading_title'] = '#ocmod.space: html5';
$_['text_extension'] = 'Розширення';
$_['text_edit'] = 'Редагування параметрів <b>Html5</b>';
$_['text_made'] = 'Зроблено з <i class="fa fa-heart-o" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> в Україні';
$_['text_about'] = 'Модуль додає до стандартного набору тек OpenCart HTML5 парсер від <a target="_blank" href="https://github.com/masterminds/html5-php">Masterminds</a>';
